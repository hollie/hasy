1. Name: Sanders Steven

2. Company: QuickSand

3. Billing address: Hoogleedsesteenweg 300 B-8800 Roeselare

4. Shipping address: Hoogleedsesteenweg 300 B-8800 Roeselare

5. Shipping option: airmail

6. Order: 4 x DSS

7. VAT BE 875.601.974

8. Notes: 

Hello,

Could you please panelize the board? 2 PCB's should fit in one DSS. 

Could you please send this board together with the 'netnode' board reorder I sent you with the same e-mail?

Thanks in advance.

Kind regards,
 Lieven.