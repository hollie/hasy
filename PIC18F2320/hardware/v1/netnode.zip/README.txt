1. Name: Hollevoet Lieven

2. Company: None

3. Billing address: Ter Zwaanhoek 16, 8400 Oostende

4. Shipping address: Ter Zwaanhoek 16, 8400 Oostende

5. Shipping option: airmail

6. Order: DSS, 1 piece

7. Notes: 

Hello,

could you please panelize the board? 4 PCB's should fit in one DSS.

Thanks in advance,
 Lieven.