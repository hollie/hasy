---- UPDATED VERSION WITH INCREASED NC DRILL PRECISION ----

1. Name: Lieven Hollevoet

2. Company: none

3. Billing address: Zonnebloemlaan 24, B8400 Oostende, Belgium

4. Shipping address: Zonnebloemlaan 24, B8400 Oostende, Belgium

5. Shipping option: airmail

6. Order: DSS, 1 piece

7. Notes: 

Hello, this is my first order with you. 

Could you please panelize the board? I think that 12 PCB's should fit in one DSS. 

I hope the line widths in the silkscreen are OK, I ran the ULP from your website to fix them.

Thanks in advance.

Kind regards,
 Lieven.